setInterval(() => {
    // Starting an interval to stay alive.
}, 1000);
