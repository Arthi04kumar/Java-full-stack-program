# Protected File

Example of a protected file to be used in the PolicyDenyFs module
