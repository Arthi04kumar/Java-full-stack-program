const fs = require('node:fs');

fs.readFileSync('/etc/passwd');