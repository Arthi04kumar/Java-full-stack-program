'use strict';
require('./throw-error.mjs');
