import { value } from "./oh'no.cjs";
