module.exports = {
  comeOn: 'fhqwhgads',
  everybody: 'to the limit',
};
