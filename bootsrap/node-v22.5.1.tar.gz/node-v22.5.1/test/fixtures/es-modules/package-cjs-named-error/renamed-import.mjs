import { comeOn as comeOnRenamed } from "./fail.cjs"
