module.exports = {
  comeOn: 'fhqwhgads'
};
