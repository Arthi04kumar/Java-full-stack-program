module.exports = {
  value: 123
};
