import Logger, { log } from 'logger';
log(new Logger(), 'import both');
