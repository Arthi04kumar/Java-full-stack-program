const test = require('./test.json');

module.exports = {
  ...test
};

test.one = 'it comes';
