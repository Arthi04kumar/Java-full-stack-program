import 'http://example.com/foo.js';
