let counter = 0;

export default function count() {
	return ++counter;
}
