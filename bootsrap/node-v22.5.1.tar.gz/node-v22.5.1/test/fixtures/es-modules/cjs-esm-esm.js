require('./package-type-module/esm.js');
