'use strict';
require('./syntax-error.mjs');
