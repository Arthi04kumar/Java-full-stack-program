module.exports = 'cjs';
console.log('executed');
