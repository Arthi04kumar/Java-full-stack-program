import './module.js';
console.log('executed');
