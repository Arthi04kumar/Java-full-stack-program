const identifier = 'package-without-type';
console.log(identifier);
module.exports = identifier;
