import('deps').then(mod => { console.log('hello ' + mod.hello); });

