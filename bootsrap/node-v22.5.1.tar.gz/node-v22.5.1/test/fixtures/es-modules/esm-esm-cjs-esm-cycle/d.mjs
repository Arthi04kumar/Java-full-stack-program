// d.mjs
import "./c.mjs";
console.log("Execute d");
