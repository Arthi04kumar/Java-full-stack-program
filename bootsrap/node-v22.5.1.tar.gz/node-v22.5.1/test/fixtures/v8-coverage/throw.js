const a = 99;
if (true) {
  const b = 101;
} else {
  const c = 102;
}
throw new Error('test');
