'use strict';
const test = require('node:test');
test('last test', () => {});
