'use strict';
const test = require('node:test');

test('j.cjs this should pass');
