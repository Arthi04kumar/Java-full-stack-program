'use strict';
const test = require('node:test');

test('g.cjs this should pass');
