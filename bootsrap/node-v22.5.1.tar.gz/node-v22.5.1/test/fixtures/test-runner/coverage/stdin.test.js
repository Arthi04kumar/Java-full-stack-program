// stdin.test.ts
var import_node_test = require("node:test");
(0, import_node_test.test)("ok", () => {
});
//# sourceMappingURL=stdin.test.js.map
