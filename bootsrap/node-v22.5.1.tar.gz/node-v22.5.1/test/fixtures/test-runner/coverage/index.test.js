'use strict';

const test = require('node:test');
test('no soucre map', () => {});
if (false) {
  console.log('this does not execute');
}
